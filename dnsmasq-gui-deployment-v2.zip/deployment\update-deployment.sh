#!/bin/bash

# DNSmasq GUI Update Deployment Script
# This script safely updates an existing installation

set -e  # Exit on any error

INSTALL_DIR="/opt/dnsmasq-gui"
SERVICE_NAME="dnsmasq-gui"
USER="pi"
GROUP="pi"

echo "=== DNSmasq GUI Update Deployment ==="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

# Check if deployment zip exists
if [ ! -f "dnsmasq-gui-deployment.zip" ]; then
    echo "Error: dnsmasq-gui-deployment.zip not found in current directory"
    exit 1
fi

# Stop the service if running
echo "Stopping $SERVICE_NAME service..."
systemctl stop $SERVICE_NAME || true

# Backup existing installation
if [ -d "$INSTALL_DIR" ]; then
    echo "Backing up existing installation..."
    mv "$INSTALL_DIR" "${INSTALL_DIR}.backup.$(date +%Y%m%d_%H%M%S)"
fi

# Create installation directory
echo "Creating installation directory..."
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# Extract deployment package
echo "Extracting deployment package..."
unzip -q "/tmp/dnsmasq-gui-deployment.zip" || {
    echo "Error: Failed to extract deployment package"
    exit 1
}

# Fix file ownership
echo "Setting correct file permissions..."
chown -R $USER:$GROUP "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
chmod +x "$INSTALL_DIR/deployment/"*.sh

# Install/update Node.js dependencies
echo "Installing Node.js dependencies..."
sudo -u $USER npm install --production

# Copy/update systemd service file
echo "Updating systemd service..."
cp "$INSTALL_DIR/deployment/dnsmasq-gui.service" /etc/systemd/system/
systemctl daemon-reload

# Enable and start service
echo "Starting $SERVICE_NAME service..."
systemctl enable $SERVICE_NAME
systemctl start $SERVICE_NAME

# Check service status
echo "Checking service status..."
if systemctl is-active --quiet $SERVICE_NAME; then
    echo "✓ $SERVICE_NAME service is running successfully"
    echo "✓ Application available at: http://$(hostname -I | awk '{print $1}'):3000"
else
    echo "✗ $SERVICE_NAME service failed to start"
    echo "Check logs with: journalctl -u $SERVICE_NAME -f"
    exit 1
fi

echo "=== Deployment completed successfully ==="
